
const menuBtn=document.querySelector('.mobile-toggle');
const menu=document.querySelector('.menu');
if(menuBtn) menuBtn.addEventListener('click',()=>menu.classList.toggle('open'));

document.querySelectorAll('[data-filter]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('[data-filter]').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const value=btn.dataset.filter;
    document.querySelectorAll('.product[data-category]').forEach(card=>{
      card.style.display=(value==='all'||card.dataset.category===value)?'block':'none';
    });
  });
});
const search=document.querySelector('#productSearch');
if(search){
 search.addEventListener('input',()=>{
   const q=search.value.toLowerCase().trim();
   document.querySelectorAll('.product[data-category]').forEach(card=>{
     card.style.display=card.innerText.toLowerCase().includes(q)?'block':'none';
   });
 });
}
document.querySelectorAll('[data-wa]').forEach(btn=>{
 btn.addEventListener('click',()=>{
   const product=btn.dataset.wa;
   const msg=encodeURIComponent(`Assalam-o-Alaikum Green Mart, I want to order: ${product}`);
   window.open(`https://wa.me/?text=${msg}`,'_blank');
 });
});
