# Green Mart Static Website

A responsive 4-page static website for Green Mart.

Pages:
- index.html — Home
- shop.html — Shop / catalogue
- about.html — About
- contact.html — Contact

Assets:
- assets/greenmart-logo.png — the logo supplied by the client

No build step or paid software is required. Open index.html directly in a browser, or upload the entire folder to a free static host such as GitHub Pages, Netlify, or Cloudflare Pages.

Notes:
- Product names/prices are based on the Green Mart catalogue visible on greenmart.com.pk at the time this site was created and should be checked before publishing.
- The contact form is a front-end placeholder. Connect it to your preferred form/email service before going live.
- The WhatsApp buttons open a generic WhatsApp chat link. Replace the link in script.js with Green Mart's confirmed WhatsApp number for direct ordering.
